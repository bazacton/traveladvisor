<?php
$conflicted_pages = array(
	"traveladvisor" => array(
		"About Us",
		"Home",
	),
);